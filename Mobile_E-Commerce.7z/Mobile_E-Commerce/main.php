<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Mobile Store</title>
<link rel="stylesheet" type="text/css" href="style.css" />

</head>
<body>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp<a href="index.html">
<a href="main.html"><img src="images/Logo123.jpg" alt="" title="" border="0" /></a>
<div id="wrap">
       <div class="header">
       		 <div class="logo"><a href="index.html"><img src="" alt="" title="" border="0" /></a></div>  
				</p></p></p></p>
        
            
            
       </div> 
       
       
       <div class="center_content">
       	<div class="left_content">
        	<div class="title"><span class="title_icon"><img src="images/bullet1.gif" alt="" title="" /></span>Individual</div>
            <div class="feat_prod_box">
            
            	<div class="prod_img"><a href="details.html"><img src="images/reg.png" alt="" title="" border="0" /></a></div>
                <br><br>
                <center><a href="register.php"> <button type="button" >Register</button></a></center>
                    
            <div class="clear"></div>
            </div>	
			<div class="feat_prod_box">
            
            	<div class="prod_img"><a href="details.html"><img src="images/login.png" alt="" title="" border="0" /></a></div>
                <br><br>
                <center><a href="myaccount.html"> <button type="button" >Log-In</button></a></center>  
            <div class="clear"></div>
            </div>	
            
        <div class="clear"></div>
        </div><!--end of left content-->
        
        <div class="right_content">
			<br>
        	<div class="languages_box">
            <span class="red">Languages:</span>
            <a href="#" class="selected"><img src="images/de.gif" alt="" title="" border="0" /></a>
            <a href="#"><img src="images/fr.gif" alt="" title="" border="0" /></a>
            <a href="#"><img src="images/gb.gif" alt="" title="" border="0" /></a>
            </div>
                <div class="currency">
                <span class="red">Currency: </span>
                <a href="#"class="selected">INR</a>
                <a href="#">EUR</a>
                <a href="#">USD</a>
                </div>
                
                
              <div class="cart">
				
                 <center><a href="adminlogin.html"> <button type="button" >Admin Log-In</button></a></center>
              </div>
                       
            	
        
        
             <div class="title"><span class="title_icon"><img src="images/bullet3.gif" alt="" title="" /></span>About Our Store</div> 
             <div class="about">
             <p>
             <img src="images/about.gif" alt="" title="" class="right" />
             Gone are the days, when you had to go on exhausting shopping trips and wait in long queues to buy something.
			 Flipkart makes online shopping as hassle-free as possible. You can always rest assured about the quality of products you are buying online at our site. 
			 Together with our trusted partners we promise to deliver only original and brand-new products, with the correct bill.
             </p>
             
             </div>
                 
             
        
        </div><!--end of right content-->
        
        
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       <div class="footer">
       	<div class="left_footer"><img src="images/footer_logo.gif" alt="" title="" /><br /> <a href="main.html" title=""><img src="images/csscreme.gif" alt="" title="" border="0" /></a></div>
        <div class="right_footer">
        <a href="#">home</a>
        <a href="#">about us</a>
        <a href="#">services</a>
        <a href="#">privacy policy</a>
        <a href="#">contact us</a>
       
        </div>
        
       
       </div>
    

</div>

</body>
</html>