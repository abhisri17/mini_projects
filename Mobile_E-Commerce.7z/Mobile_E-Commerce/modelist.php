<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Mobile Store</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp<a href="index.html">
<a href="index.html"><img src="images/Logo123.jpg" alt="" title="" border="0" /></a>
<div id="wrap">

       <div class="header">
       		<div class="logo"><a href="index.html"><img src="" alt="" title="" border="0" /></a></div>  
				</p></p></p></p>            
        <div id="menu">
            <ul>                                                                       
            <li><a href="index.html">home</a></li>
            <li><a href="about.html">about us</a></li>
            <li><a href="category.html">mobiles</a></li>
            <li><a href="accessories.html">accessories</a></li>
            <li><a href="details.html">trending</a></li>
            <li><a href="contact.php">contact</a></li>
			<li><a href="search.html">search</a></li>
            </ul>
        </div>     
            
            
       </div> 
       
       
       <div class="center_content">
       	<div class="left_content">
            <div class="title"><span class="title_icon"><img src="images/bullet1.gif" alt="" title="" /></span>Mobile List</div>
        
        	<div class="feat_prod_box_details">
            
            <table class="cart_table">
            	<tr class="cart_title">
                
                	<td>Brand</td>
                    <td>Model</td>
                    <td>Price</td>               
                </tr>
                <?php
						mysql_connect("localhost","root","");
						mysql_select_db("mces");
						$typ=$_GET['var'];
						$q1="select * from addmob where model='$typ' order by price";
						$run=mysql_query($q1);
						while ($row=mysql_fetch_array($run))
						{
				?>	
            	<tr>
                	<td><?php echo $row["brand"] . "<br />";?></td>
					<td><a href="desc.php?var=<?php echo $row['model']?>"><?php echo $row['model']?></a></td>
					<td><?php echo $row["price"] . "<br />";?></td>              
                </tr>                            
            
            
            
				<?php		}
						
						
				?>	
         
				</table>
					<a href="index.html" class="continue">&lt; Home</a>
					<a href="search.html" class="checkout"> Search&gt;</a>
            
            </div>	
            
              

            

            
        <div class="clear"></div>
        </div><!--end of left content-->
        
        <div class="right_content">
        	<div class="languages_box">
            <span class="red">Languages:</span>
            <a href="#" class="selected"><img src="images/de.gif" alt="" title="" border="0" /></a>
            <a href="#"><img src="images/fr.gif" alt="" title="" border="0" /></a>
            <a href="#"><img src="images/gb.gif" alt="" title="" border="0" /></a>
            </div>
                <div class="currency">
                <span class="red">Currency: </span>
                <a href="#"class="selected">INR</a>
                <a href="#">EUR</a>
                <a href="#">USD</a>
                </div>
                
                
              <div class="cart">
                  <div class="title"><span class="title_icon"><img src="images/cart.gif" alt="" title="" /></span>My cart</div>
                  
                  <a href="cart.php" class="view_cart">view cart</a>
				  <a href="logout.php" class="view_cart">Log-out</a>
              
              </div>
                       
            	
        
        
             <div class="title"><span class="title_icon"><img src="images/bullet3.gif" alt="" title="" /></span>About Our Store</div> 
             <div class="about">
             <p>
             <img src="images/about.gif" alt="" title="" class="right" />
             Gone are the days, when you had to go on exhausting shopping trips and wait in long queues to buy something.
			 Flipkart makes online shopping as hassle-free as possible. You can always rest assured about the quality of products you are buying online at our site. 
			 Together with our trusted partners we promise to deliver only original and brand-new products, with the correct bill.
             </p>
             
             </div>
             
             <div class="right_box">
             
             	<div class="title"><span class="title_icon"><img src="images/bullet4.gif" alt="" title="" /></span>Promotions</div> 
                    <div class="new_prod_box">
                        <a href="modelist.php?var=581">Blackberry 581</a>
                        <div class="new_prod_bg">
                        <span class="new_icon"><img src="images/promo_icon.gif" alt="" title="" /></span>
                        <a href="modelist.php?var=581"><img src="images/thumb1.jpg" alt="" title="" class="thumb" border="0" /></a>
                        </div>           
                    </div>
                    
                    <div class="new_prod_box">
                        <a href="modelist.php?var=lumia535">Microsoft Lumia 535</a>
                        <div class="new_prod_bg">
                        <span class="new_icon"><img src="images/promo_icon.gif" alt="" title="" /></span>
                        <a href="modelist.php?var=lumia535"><img src="images/thumb2.jpg" alt="" title="" class="thumb" border="0" /></a>
                        </div>           
                    </div>                    
                    
                    <div class="new_prod_box">
                        <a <a href="modelist.php?var=5620">>Samsung 5620</a>
                        <div class="new_prod_bg">
                        <span class="new_icon"><img src="images/promo_icon.gif" alt="" title="" /></span>
                        <a <a href="modelist.php?var=5620"><img src="images/thumb3.jpg" alt="" title="" class="thumb" border="0" /></a>
                        </div>           
                    </div>              
             
             </div>
             
             <div class="right_box">
             
             	<div class="title"><span class="title_icon"><img src="images/bullet5.gif" alt="" title="" /></span>Categories</div> 
                
                <ul class="list">
                <li><a href="asearch.html">accesories</a></li>
                <li><a href="asclist.php?var=earphone">earphones</a></li>
                <li><a href="asclist.php?var=headphone">headphones</a></li>
                <li><a href="asclist.php?var=battery">batteries</a></li>
                <li><a href="asclist.php?var=casecover">cases & covers</a></li>
				<li><a href="asclist.php?var=charger">chargers</a></li>
				<li><a href="asclist.php?var=usb">USB</a></li>
                </ul>
                
             	<div class="title"><span class="title_icon"><img src="images/bullet6.gif" alt="" title="" /></span>Partners</div> 
                
                <ul class="list">
                <li><a href="brandlist.php?var=accord">Accord Mobiles</a></li>
                <li><a href="brandlist.php?var=acer">Acer Mobiles</a></li>
                <li><a href="brandlist.php?var=apple">Apple</a></li>
                <li><a href="brandlist.php?var=blackberry">Blackberry</a></li>
                <li><a href="brandlist.php?var=dell">Dell Mobiles</a></li>
                <li><a href="brandlist.php?var=htc">HTC</a></li>
                <li><a href="brandlist.php?var=lg">LG Mobiles</a></li>
                <li><a href="brandlist.php?var=micromax">Micromax Mobiles</a></li>
				<li><a href="brandlist.php?var=microsoft">Microsoft</a></li>
				<li><a href="brandlist.php?var=samsung">Samsung</a></li>
				<li><a href="brandlist.php?var=redmi">RedMi</a></li>
                </ul>      
             
             </div>         
             
        
        </div><!--end of right content-->
        
        
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       <div class="footer">
       	<div class="left_footer"><img src="images/footer_logo.gif" alt="" title="" /><br /> <a href="index.html" title=""><img src="images/csscreme.gif" alt="" title="" border="0" /></a></div>
        <div class="right_footer">
        <a href="#">home</a>
        <a href="#">about us</a>
        <a href="#">services</a>
        <a href="#">privacy policy</a>
        <a href="#">contact us</a>
       
        </div>
        
       
       </div>
    

</div>

</body>
</html>