<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
<title>Mobile Store</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
&nbsp&nbsp&nbsp&nbsp&nbsp<a href="index.html">
<a href="index.html"><img src="images/Logo123.jpg" alt="" title="" border="0" /></a>
<div id="wrap">

       <div class="header">
       		<div class="logo"><a href="index.html"><img src="" alt="" title="" border="0" /></a></div>  
				</p></p></p></p>            
        <div id="menu">
            <ul>                                                                       
            <li><a href="index.html">home</a></li>
            <li><a href="about.html">about us</a></li>
            <li><a href="category.html">mobiles</a></li>
            <li><a href="accessories.html">accesories</a></li>
            <li><a href="details.html">trending</a></li>
            <li class="selected"><a href="contact.php">contact</a></li>
			<li><a href="search.html">search</a></li>
            </ul>
        </div>     
            
            
       </div> 
       
       
       <div class="center_content">
       	<div class="left_content">
            <div class="title"><span class="title_icon"><img src="images/bullet1.gif" alt="" title="" /></span>Contact Us</div>
        
        	<div class="feat_prod_box_details">
            <p class="details">
             If you have any complaint or query about our products or services please write us providing your information asked below. 
			 We'll reply with a solution as soon as possible. We will will be in touch unless your complaint is resolved====>
            </p>
            
              	<div class="contact_form">
                <div class="form_subtitle">Complaints</div>          
                    <form action=" " method="POST">
					
					Brand:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					<input type="text" name="brand" placeholder=""><p>
					Model Name:&nbsp&nbsp&nbsp&nbsp&nbsp
					<input type="text" name="model" /><p>
					Buy Date:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					<input type="date" name="date" /><p>
					Phone:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					<input type="text" name="phone" /><p>
					E-mail:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					<input type="text" name="email" /><p>
					Complaint:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					<textarea name = "complaint"  rows = "5� 
						cols = "50">
					</textarea><p><p>
                    <br><center><input type="submit" name ="submit" value="submit"/></center></br>
					</form>      
                </div>  
                <div class="contact_form">
                         <div class="form_subtitle">Contact Address
						 </div>          
                      

                    
                    
					Please feel free to come visit us at the following address:
					<br><br><b>M.G Road, 210
					<br>Kochi-682001,
					<br>Kerala-India
					<br>Ph no.:&nbsp&nbsp&nbsp1800-111-123
					
					<br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp1800-111-567</b>
					<br><br>
					<a href="index.html"><img src="images/mst1.jpg" alt="" title="" border="0" /></a>

                    
                          
                     </div>
          </div>	
            
              

            

            
        <div class="clear"></div>
        </div><!--end of left content-->
        
        <div class="right_content">
        	<div class="languages_box">
            <span class="red">Languages:</span>
            <a href="#" class="selected"><img src="images/de.gif" alt="" title="" border="0" /></a>
            <a href="#"><img src="images/fr.gif" alt="" title="" border="0" /></a>
            <a href="#"><img src="images/gb.gif" alt="" title="" border="0" /></a>
            </div>
                <div class="currency">
                <span class="red">Currency: </span>
                <a href="#"class="selected">INR</a>
                <a href="#">EUR</a>
                <a href="#">USD</a>
                </div>
                
                
              <div class="cart">
                  <div class="title"><span class="title_icon"><img src="images/cart.gif" alt="" title="" /></span>My cart</div>
                  
                  <a href="cart.php" class="view_cart">view cart</a>
				  <a href="logout.php" class="view_cart">Log-out</a>
              
              </div>
                       
            	
        
        
             <div class="title"><span class="title_icon"><img src="images/bullet3.gif" alt="" title="" /></span>About Our Store</div> 
             <div class="about">
             <p>
             <img src="images/about.gif" alt="" title="" class="right" />
             Gone are the days, when you had to go on exhausting shopping trips and wait in long queues to buy something.
			 Flipkart makes online shopping as hassle-free as possible. You can always rest assured about the quality of products you are buying online at our site. 
			 Together with our trusted partners we promise to deliver only original and brand-new products, with the correct bill.
             </p>
             
             </div>
             
             <div class="right_box">
             
             	<div class="title"><span class="title_icon"><img src="images/bullet4.gif" alt="" title="" /></span>Promotions</div> 
                    <div class="new_prod_box">
                        <a href="modelist.php?var=581">Blackberry 581</a>
                        <div class="new_prod_bg">
                        <span class="new_icon"><img src="images/promo_icon.gif" alt="" title="" /></span>
                        <a href="modelist.php?var=581"><img src="images/thumb1.jpg" alt="" title="" class="thumb" border="0" /></a>
                        </div>           
                    </div>
                    
                    <div class="new_prod_box">
                        <a href="modelist.php?var=lumia535">Microsoft Lumia 535</a>
                        <div class="new_prod_bg">
                        <span class="new_icon"><img src="images/promo_icon.gif" alt="" title="" /></span>
                        <a href="modelist.php?var=lumia535"><img src="images/thumb2.jpg" alt="" title="" class="thumb" border="0" /></a>
                        </div>           
                    </div>                    
                    
                    <div class="new_prod_box">
                        <a <a href="modelist.php?var=5620">Samsung 5620</a>
                        <div class="new_prod_bg">
                        <span class="new_icon"><img src="images/promo_icon.gif" alt="" title="" /></span>
                        <a <a href="modelist.php?var=5620"><img src="images/thumb3.jpg" alt="" title="" class="thumb" border="0" /></a>
                        </div>           
                    </div>              
             
             </div>
             
             <div class="right_box">
             
             	<div class="title"><span class="title_icon"><img src="images/bullet5.gif" alt="" title="" /></span>Categories</div> 
                
                <ul class="list">
                <li><a href="asearch.html">accesories</a></li>
                <li><a href="asclist.php?var=earphone">earphones</a></li>
                <li><a href="asclist.php?var=headphone">headphones</a></li>
                <li><a href="asclist.php?var=battery">batteries</a></li>
                <li><a href="asclist.php?var=casecover">cases & covers</a></li>
				<li><a href="asclist.php?var=charger">chargers</a></li>
				<li><a href="asclist.php?var=usb">USB</a></li>
                </ul>
                
             	<div class="title"><span class="title_icon"><img src="images/bullet6.gif" alt="" title="" /></span>Partners</div> 
                
                <ul class="list">
                <li><a href="brandlist.php?var=accord">Accord Mobiles</a></li>
                <li><a href="brandlist.php?var=acer">Acer Mobiles</a></li>
                <li><a href="brandlist.php?var=apple">Apple</a></li>
                <li><a href="brandlist.php?var=blackberry">Blackberry</a></li>
                <li><a href="brandlist.php?var=dell">Dell Mobiles</a></li>
                <li><a href="brandlist.php?var=htc">HTC</a></li>
                <li><a href="brandlist.php?var=lg">LG Mobiles</a></li>
                <li><a href="brandlist.php?var=micromax">Micromax Mobiles</a></li>
				<li><a href="brandlist.php?var=microsoft">Microsoft</a></li>
				<li><a href="brandlist.php?var=samsung">Samsung</a></li>
				<li><a href="brandlist.php?var=redmi">RedMi</a></li>
                </ul>      
             
             </div>         
             
        
        </div><!--end of right content-->
        
        
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       <div class="footer">
       	<div class="left_footer"><img src="images/footer_logo.gif" alt="" title="" /><br /> <a href="index.html" title=""><img src="images/csscreme.gif" alt="" title="" border="0" /></a></div>
        <div class="right_footer">
        <a href="#">home</a>
        <a href="#">about us</a>
        <a href="#">services</a>
        <a href="#">privacy policy</a>
        <a href="#">contact us</a>
       
        </div>
        
       
       </div>
    

</div>

</body>
</html>
<?php

mysql_connect("localhost","root","");
mysql_select_db("mces");


if(isset($_POST['submit'])) 
{
  
  
  $brand = $_POST['brand'];
  $model = $_POST['model'];
  $date = $_POST['date'];
  $phone = $_POST['phone'];
  $email = $_POST['email'];
  $complaint = $_POST['complaint'];
   
  if($brand=='' OR $model=='' OR $date=='' OR $phone=='' OR $email=='' OR $complaint=='')
  {
    echo "<script>alert('fill in the all field')</script>";
    echo "<script>window.open('contact.php','_self')</script>";
  }


 $insert_complain="insert into complain(brand,model,date,phone,email,complaint) values('$brand','$model','$date','$phone','$email','$complaint')";
    
  if($run_post=mysql_query($insert_complain))
  	echo "<script>alert('Registration Successfull')</script>";
  	echo "<script>window.open('index.html','_self')</script>";

}
else
	echo "hello";
?>
